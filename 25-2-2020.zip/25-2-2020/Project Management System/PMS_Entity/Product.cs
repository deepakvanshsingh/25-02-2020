﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS_Entity
{
    public class Product
    {
        public int productId { get; set; }
        public string productName { get; set; }
        public int productPrice { get; set; }
        public int productQuantity { get; set; }
    }
}
