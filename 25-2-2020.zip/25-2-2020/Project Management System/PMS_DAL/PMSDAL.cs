﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_Entity;
using PMS_Exception;
using System.Data;
using System.Data.SqlClient;
namespace PMS_DAL
{
    public class PMSDAL
    {
       static string ConString = Config.ConnectionString;
        SqlConnection connection = new SqlConnection(ConString);
        SqlCommand cmd;
        public bool AddProductDAL(Product product)
        {
            bool isProductAdded = false;
            try
            {
                // string query = "insert into Products_dsingh58 values(@ProductId,@ProductName,@ProductPrice,@ProductQuantity)";
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                cmd = new SqlCommand();
                cmd.CommandText = "AddProducts_dsingh58";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ProductId", product.productId);
                cmd.Parameters.AddWithValue("@ProductName", product.productName);
                cmd.Parameters.AddWithValue("@ProductPrice", product.productPrice);
                cmd.Parameters.AddWithValue("@ProductQuantity", product.productQuantity);

                SqlParameter parameter = new SqlParameter();
                parameter.ParameterName = "isAdded";
                parameter.SqlDbType = SqlDbType.Int;
                parameter.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(parameter);
                cmd.Connection = connection;
                cmd.ExecuteNonQuery();
                if (int.Parse(parameter.Value.ToString()) == 1)
                {
                    isProductAdded = true;
                }
               
            }
            catch (SqlException EX)
            {
                throw new ProductException(EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }

            
            return isProductAdded;
        }
        public DataTable GetAllProductDAL()
        {
            DataTable table = new DataTable();
            try
            {
                // string query = "insert into Products_dsingh58 values(@ProductId,@ProductName,@ProductPrice,@ProductQuantity)";
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                cmd = new SqlCommand();
                cmd.CommandText = "SelectProducts_dsingh58";
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.AddWithValue("@ProductId", product.productId);
                //cmd.Parameters.AddWithValue("@ProductName", product.productName);
                //cmd.Parameters.AddWithValue("@ProductPrice", product.productPrice);
                //cmd.Parameters.AddWithValue("@ProductQuantity", product.productQuantity);

                SqlParameter parameter = new SqlParameter();
                parameter.ParameterName = "isUpdated";
                parameter.SqlDbType = SqlDbType.Int;
                parameter.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(parameter);
                cmd.Connection = connection;

                SqlDataReader reader = cmd.ExecuteReader();
                table.Load(reader);

            }
            catch (SqlException EX)
            {
                throw new ProductException(EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
            return table;
        }

        }
}
