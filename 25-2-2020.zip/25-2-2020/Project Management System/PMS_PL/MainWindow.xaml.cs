﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PMS_BLL;
using PMS_Entity;
using PMS_Exception;

namespace PMS_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        PMSBLL bll = new PMSBLL();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int id = 0;
            int price = 0;
            int quantity = 0;
            if (productId.Text != String.Empty)
                id = int.Parse(productId.Text);
            string name = productName.Text;
            if (productPrice.Text != String.Empty)
                price = int.Parse(productPrice.Text);
            if (productQuantity.Text != String.Empty)
                quantity = int.Parse(productQuantity.Text);
            /*************initialize member variable of entity******************/
            Product product = new Product();
            product.productId = id;
            product.productName = name;
            product.productPrice = price;
            product.productQuantity = quantity;
            
            try
            {
                if (bll.AddProductBLL(product))
                    MessageBox.Show("Product Added successfully!!");

            }
            catch (ProductException ex)
            {
                MessageBox.Show("ExceptionOcurred:" + ex.Message);
            }
            productDetails.DataContext= bll.GetAllProductBll();
        }
        
    }
}
