﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_Entity;
using PMS_Exception;
using PMS_DAL;
using System.Data;
namespace PMS_BLL
{
    public class PMSBLL
    {
        PMSDAL dal = new PMSDAL();
        public bool AddProductBLL(Product product)
        {
            
            bool isProductAdded = false;
            if (ValidateProduct(product))
            {
              isProductAdded=dal.AddProductDAL(product);
            }
            return isProductAdded;
        }
        public bool ValidateProduct(Product product)
        {
            StringBuilder exceptionMessage = new StringBuilder();
            bool isProductValid = true;
            try
            {


                if (product.productId <= 0)
                {
                    isProductValid = false;
                    exceptionMessage.Append("Invalid product id!!");
                }
                if (product.productName == String.Empty || product.productName == null)
                {
                    isProductValid = false;
                    exceptionMessage.Append("Invalid product Name!!");
                }
                if (product.productPrice <= 0)
                {
                    isProductValid = false;
                    exceptionMessage.Append("Invalid product price!!");
                }
                if (product.productQuantity <= 0)
                {
                    isProductValid = false;
                    exceptionMessage.Append("Invalid product quantity!!");
                }
                if (isProductValid == false)
                {
                    throw new ProductException(exceptionMessage.ToString());
                }

            }
            catch (ProductException)
            {
                throw;
            }
            return isProductValid;
        }

        public DataTable GetAllProductBll()
        {
            return dal.GetAllProductDAL();
        }
    }
}
